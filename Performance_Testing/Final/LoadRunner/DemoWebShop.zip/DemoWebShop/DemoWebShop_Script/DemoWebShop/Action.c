Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("Nop.customer=ad46ea6a-ce96-4a68-9096-ec4be7e6dd70; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinity=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinitySameSite=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-GB,en-US;q=0.9,en;q=0.8");

/*Correlation comment - Do not change!  Original value='laptop' Name ='C_SearchItem' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_SearchItem",
		"RegExp=141-inch-(.*?)\"\\ title",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/demowebshop.tricentis.com/*",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-divider.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/bullet-right.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-active.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-inactive.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-triangle.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		LAST);

	lr_think_time(2);

	lr_start_transaction("1_Login");

	web_url("Log in", 
		"URL=https://demowebshop.tricentis.com/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Accept-Language", 
		"en-GB,en-US;q=0.9,en;q=0.8");

	web_submit_data("login", 
		"Action=https://demowebshop.tricentis.com/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/login", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=Email", "Value={Username}", ENDITEM, 
		"Name=Password", "Value={Password}", ENDITEM, 
		"Name=RememberMe", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_small.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	lr_end_transaction("1_Login",LR_AUTO);
	
	lr_think_time(2);
	
	lr_start_transaction("2_SearchProduct");

//	web_url("searchtermautocomplete", 
//		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=laptops", 
//		"TargetFrame=", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=https://demowebshop.tricentis.com/", 
//		"Snapshot=t4.inf", 
//		"Mode=HTML", 
//		LAST);
//
//	web_url("search", 
//		"URL=https://demowebshop.tricentis.com/search?q=laptops", 
//		"TargetFrame=", 
//		"Resource=0", 
//		"RecContentType=text/html", 
//		"Referer=https://demowebshop.tricentis.com/", 
//		"Snapshot=t5.inf", 
//		"Mode=HTML", 
//		LAST);

	web_add_cookie("__utmb=78382081.3.10.1790848845; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(2);

	web_url("searchtermautocomplete_2",
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term={C_SearchItem}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/search?q={C_SearchItem}s",
		"Snapshot=t6.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("__utmb=78382081.4.10.1790848845; DOMAIN=demowebshop.tricentis.com");

	web_url("search_2",
		"URL=https://demowebshop.tricentis.com/search?q={C_SearchItem}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/search?q={C_SearchItem}s",
		"Snapshot=t7.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/Themes/DefaultClean/Content/images/ajax_loader_large.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM,
		LAST);

	lr_end_transaction("2_SearchProduct",LR_AUTO);

	lr_think_time(2);
	
	lr_start_transaction("3_AddToCart");

	web_custom_request("1",
		"URL=https://demowebshop.tricentis.com/addproducttocart/catalog/31/1/1",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/search?q={C_SearchItem}",
		"Snapshot=t8.inf",
		"Mode=HTML",
		"EncType=",
		EXTRARES,
		"URL=/content/images/thumbs/0000224_141-inch-{C_SearchItem}_47.png", "Referer=https://demowebshop.tricentis.com/search?q={C_SearchItem}", ENDITEM,
		"URL=/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM,
		LAST);

	lr_end_transaction("3_AddToCart",LR_AUTO);

	lr_think_time(2);

	lr_start_transaction("4_ClickCart");

	web_url("cart",
		"URL=https://demowebshop.tricentis.com/cart",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/search?q={C_SearchItem}",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("4_ClickCart",LR_AUTO);

	lr_start_transaction("5_Checkout");

	web_add_cookie("__utmb=78382081.5.10.1790848845; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=removefromcart", "Value={removefromcart}", ENDITEM, 
		"Name=itemquantity7121833", "Value={Qunatity}", ENDITEM, 
		"Name=discountcouponcode", "Value={CouponCode}", ENDITEM, 
		"Name=giftcardcouponcode", "Value={GiftCardCupon}", ENDITEM, 
		"Name=CountryId", "Value={CountryId}", ENDITEM, 
		"Name=StateProvinceId", "Value={stateId}", ENDITEM, 
		"Name=ZipPostalCode", "Value={ZipCode}", ENDITEM, 
		"Name=termsofservice", "Value={termsOfService}", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		EXTRARES, 
		"Url=/plugins/Payments.Manual/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.CheckMoneyOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.PurchaseOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.CashOnDelivery/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		LAST);

	lr_end_transaction("5_Checkout",LR_AUTO);
	
	lr_think_time(2);
	
	lr_start_transaction("6_ContinueAfterCheckout");

	web_add_cookie("__utmb=78382081.6.10.1790848845; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(2);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=billing_address_id", "Value=5157646", ENDITEM, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={FirstName}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={LastName}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value={Email}", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value={Company}", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value={CountryId}", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value={stateId}", ENDITEM, 
		"Name=BillingNewAddress.City", "Value={cityId}", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value={Address1}", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value={Address2}", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value={ZipCode}", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value={PhoneNumber}", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value={FaxNumber}", ENDITEM, 
		EXTRARES, 
		"Url=/Themes/DefaultClean/Content/images/arrow-up.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5157646", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=Shashank", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=Manurey", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=shashank1234@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_think_time(10);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_cookie("ASP.NET_SessionId=byav3lbnh5i33xxswf5hb0dk; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(4);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("6_ContinueAfterCheckout",LR_AUTO);

	return 0;
}