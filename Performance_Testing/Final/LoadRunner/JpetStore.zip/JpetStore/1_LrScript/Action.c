Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='FISH' Name ='C_category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_category",
		"RegExp=categories/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("pets.png", 
		"URL=https://petclinic.aspectran.com/images/pets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(30);

	lr_start_transaction("1_Navigate");

	lr_end_transaction("1_Navigate",LR_AUTO);

	lr_start_transaction("2_catogories");

/*Correlation comment - Do not change!  Original value='FI-SW-01' Name ='productid' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=productid",
		"RegExp=products/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Fish",
		"URL=https://jpetstore.aspectran.com/categories/{C_category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t7.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("2_catogories",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("3_product");

/*Correlation comment - Do not change!  Original value='EST-1' Name ='itemId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=itemId",
		"RegExp=items/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("FI-SW-01",
		"URL=https://jpetstore.aspectran.com/products/{productid}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{C_category}",
		"Snapshot=t8.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("3_product",LR_AUTO);

	lr_think_time(6);

	lr_start_transaction("4_item");

	web_url("EST-1",
		"URL=https://jpetstore.aspectran.com/products/{productid}/items/{itemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{productid}",
		"Snapshot=t9.inf",
		"Mode=HTTP",
		LAST);

	web_url("fish1.jpg",
		"URL=https://jpetstore.aspectran.com/images/fish1.jpg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://jpetstore.aspectran.com/products/{productid}/items/{itemId}",
		"Snapshot=t10.inf",
		LAST);

	lr_end_transaction("4_item",LR_AUTO);

	lr_start_transaction("5_addtocart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={itemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{productid}/items/{itemId}",
		"Snapshot=t11.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_addtocart",LR_AUTO);

	lr_start_transaction("6_checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_checkout",LR_AUTO);

	lr_start_transaction("7_login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={Username}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t14.inf", 
		LAST);

	lr_end_transaction("7_login",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("8_continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value={CreditCard}", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_continue",LR_AUTO);

	lr_start_transaction("9_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_confirm",LR_AUTO);

	return 0;
}